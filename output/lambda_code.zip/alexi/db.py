import boto3

def get_latest_row():
    # TODO - DO!
    return {
        'speed': 100.7
    }
